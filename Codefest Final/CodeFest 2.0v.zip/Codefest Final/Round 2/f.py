a=1
b=2
c= 0
n = 56

while n-2>0:
    c = a+b
    a=b
    b=c
    n-=1

print(c)
