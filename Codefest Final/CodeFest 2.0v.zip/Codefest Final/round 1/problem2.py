a= 1250
b = 1898
sum = 0
while(a<b):
    if a%2==0:
        sum += a
    a += 1

print(sum)